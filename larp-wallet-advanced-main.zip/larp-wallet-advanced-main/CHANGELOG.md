# Changelog — Larp Wallet Advanced

All notable changes documented here.

## [Unreleased]

### Added
- 10/10 README with wallet skin showcase and ethics guidelines
- CHANGELOG.md

## [1.0.0]

### Added
- 👻 Phantom wallet simulator (`index.html`)
- 🛡️ Trust Wallet simulator (`trust.html`)
- 🅿️ PayPal simulator (`paypal.html`)
- 🏠 Skin picker hub (`hub.html`)
- Editable balances with LocalStorage persistence
- PWA support (installable, offline-capable)
- Screenshot-optimized layouts
