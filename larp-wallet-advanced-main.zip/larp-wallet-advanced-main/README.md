<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:6b21a8,100:1e1b4b&height=200&section=header&text=💳%20Larp%20Wallet&fontSize=54&fontColor=ffffff&animation=fadeIn" />

# Advanced Larp Wallet Simulator

[![PWA](https://img.shields.io/badge/PWA-Ready-5A0FC8?style=for-the-badge&logo=pwa&logoColor=white)](https://web.dev/progressive-web-apps/)
[![Skins](https://img.shields.io/badge/Skins-4%20Wallets-7C3AED?style=for-the-badge)](https://github.com/Rustys90/larp-wallet-advanced)
[![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)](LICENSE)

**The ultimate wallet mockup studio** for content creators. Simulate Phantom, Trust Wallet, and PayPal interfaces with fully editable balances — perfect for screenshots, videos, tutorials, and demos.

> ⚠️ **For content creation only.** This is a visual simulator — no real crypto, no real money, no blockchain connection.

</div>

---

## 🎭 Wallet Skins

<div align="center">

| Skin | App | File |
|:----:|:---:|:----:|
| 👻 | **Phantom** | `index.html` |
| 🛡️ | **Trust Wallet** | `trust.html` |
| 🅿️ | **PayPal** | `paypal.html` |
| 🏠 | **Skin Picker** | `hub.html` |

</div>

## ✨ Features

- 💰 **Editable Balances** — click any number, type a new one (saved to LocalStorage)
- 🎨 **Pixel-Perfect Skins** — faithful recreations of real wallet UIs
- 📱 **PWA Ready** — installable, works offline
- 🖼️ **Screenshot Mode** — clean layouts optimized for captures
- 🎬 **Content Ready** — perfect for YouTube thumbnails, tutorials, demos
- 💾 **Persistent** — your edits survive refreshes via LocalStorage

## 🚀 Quick Start

```bash
# Clone
git clone https://github.com/Rustys90/larp-wallet-advanced.git
cd larp-wallet-advanced

# Serve (any static server)
npx serve .
# or
python3 -m http.server 8000
```

Open `hub.html` → pick a wallet → start creating! 🎨

## 📁 Project Structure

```
larp-wallet-advanced/
├── hub.html        # Skin picker / launcher
├── index.html      # 👻 Phantom wallet
├── trust.html      # 🛡️ Trust Wallet
├── paypal.html     # 🅿️ PayPal
└── README.md
```

## 🎯 Use Cases

- 📸 **Thumbnails** — crypto YouTube thumbnails without real funds
- 🎓 **Tutorials** — demonstrate wallet features safely
- 🎬 **Demos** — pitch decks and product mockups
- 🧪 **UI Testing** — design reference for wallet interfaces

## ⚖️ Legal & Ethics

This tool is for **legitimate content creation**. Do not use it to deceive, scam, or misrepresent real financial holdings. Always disclose when showing simulated balances.

## 🤝 Contributing

New wallet skins welcome! PRs with pixel-faithful recreations get priority.

## 📄 License

MIT — create responsibly! 💳

---

<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:1e1b4b,100:6b21a8&height=120&section=footer" />

**Built with 💳 by [Rustys90](https://github.com/Rustys90)**

</div>
